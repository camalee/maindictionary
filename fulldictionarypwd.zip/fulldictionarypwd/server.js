const express = require('express');
const app = express();
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require("body-parser");
const session = require('express-session');
const User = require('./models/user');
//const Dictionary = require('./models/dictionary');
const dbUrl = process.env.DB_URL


const dictionaryRoute = require('./routes/dictionary');

//mongodb://localhost:27017/newdictionarydata
mongoose.connect('mongodb://localhost:27017/newdictionarydata',{
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology : true,
})

.then(() => {
  console.log (" Mongo database connected")
})
.catch(err => {
  console.log ("No mongo database connection")
  console.log(err)
})


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

//middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json())

app.use(session({secret:'bad secret'}))

const requireLogin = (req, res, next) => {
  if (!req.session.user_id) {
      return res.redirect('/login') // if not login require you to login
  }
  next();
}
//------Routes------

app.use('/', dictionaryRoute);
////--------------Home/Welcome Section --------------------
  app.get('/', (req, res) => {
    res.render('pages/welcome')
  });
 ////--------------Register Section --------------------
app.get('/register',  (req, res) => {
    res.render('pages/register')
  })

app.post('/register', async (req, res) => {
    const{password,username} = req.body;
    const user = new User({username,password})
    await user.save();
    req.session.user_id = user._id;
    res.redirect('/login')
  })

 ////--------------Login Section --------------------
  app.get('/login',  (req, res) => {
    res.render('pages/login')
  })

  app.post('/login', async (req, res) => {
    const {username, password} = req.body;
    //const user = await User.findOne({username}); //find username 
    const userFound = await User.findAndValidatePwd(username, password)
    if (userFound){ 
        req.session.user_id = userFound._id; // if you are successfully logged in , store user in session
        res.redirect('/dictionary'); // login gets access to secret site : dictionary
        //res.send("yaaaaayy");
    }
    else{
        res.redirect('/dictionary');
    }

  })
//// Logout section-------------
app.get('/logout',  (req, res) => {
  res.render('pages/logout')
})
app.post('/logout', async (req, res) => {
  //req.session.user_id = null; // stop tracking user id 
  req.session.destroy(); // clean slate
  res.redirect('/login');
})

////--------------Dictionary : Authorized Section --------------------
app.get('/dictionary',requireLogin ,(req, res) => {
   res.render('dictionary')
   })

      



const port = process.env.PORT ||5003;

//starting the server
app.listen(port, () => {
    console.log(`This app is listening on http://localhost:${port}`)})



