const router = require('express').Router();
const fetch = require('node-fetch');
var bodyParser = require('body-parser');
require('dotenv').config()
//var Dictionary = require('./models/dictionary');
const { Mongoose } = require('mongoose');
// const dictionary = require('nedb')
// //const dict = []
// const dict =  new dictionary('newdictionary.db')
// dict.loadDatabase();

    router.get('/dictionary', (req, res) => {
        res.render('pages/dictionary', {
          //set to null so first time users of app get a blank index file
          word: null,
            partofspeech: null,
            definition: null,
            image: null,
          
        });
      });
      
      router.post('/dictionary', async (req, res) => {
        const word = req.body.word;
        const url = `https://dictionaryapi.com/api/v3/references/collegiate/json/${word}?key=${process.env.API_KEY}`;  
      
        try {
          await fetch(url)
            .then(res => res.json())
            .then(data =>  {
                const word = data[0].hwi.hw; //word
                const partofspeech = data[0].fl; // part of speech
                const definition = data[0].shortdef//definition
                const image = data[0].art //image
      
               
                res.render('pages/dictionary', {
                    word,partofspeech,definition,image,  // same as above variable names
                });
                // const timestamp = Data.now();
                // data.timestamp = timestamp;
                // dict.insert(data);
                // console.log(data);

                dict.push(word);
                dict.push(partofspeech);
                dict.push(definition);
                dict.push(image);
                console.log(word ,partofspeech, definition,image);
                
                
              });
            
        } catch (err) {
          res.render('pages/dictionary', {
            word: 'Oh no! That word does not exist',
            partofspeech: null,
            definition: null,
            image: null,
            
          })
        }
        

        
      })

      module.exports = router;
