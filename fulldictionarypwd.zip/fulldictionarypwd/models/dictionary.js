const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const dictionarySchema = new Schema({
    word: String,
    partofspeech: String,
    definition: String,       
    image: String,        
});          

module.exports = mongoose.model('Dictionary', dictionarySchema);