const mongoose = require('mongoose')
const bcrypt = require('bcrypt');

const Schema = mongoose.Schema;


const userSchema = new Schema({
    
    username: {type:String,required:[true, 'Enter a username. It cannot be blank']},
    password: {type:String,required:[true, 'Enter a password. It cannot be blank']},//hashed pwd
    //date:{type:Date,default:Date.now},
       
});
// match pwd entered in form with hashed pwd saved in database
userSchema.statics.findAndValidatePwd = async function(username,password){
  const userFound =  await this.findOne({username});
  
  const isValid = await bcrypt.compare(password, userFound.password);
  return isValid ? userFound : false;
}
//middleware 
userSchema.pre('save',async function(next){
    //only rehash pwd if pwd is modified/changed
    if(!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password,12); // the pwd for the user model that is being saved is being hashed
    next();
})
  
//export
module.exports = mongoose.model('User', userSchema)